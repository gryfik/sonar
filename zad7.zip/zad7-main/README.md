# zad7
![image](https://github.com/user-attachments/assets/1084551d-5979-4612-bd79-ee6944062138)
